package com.example.onlinemovie.modeltests;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

import com.example.onlinemovie.model.Customer;
import com.example.onlinemovie.model.Product;
import com.example.onlinemovie.repository.CustomerRepository;
import com.example.onlinemovie.repository.ProductRepository;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;



@RunWith(SpringRunner.class)
@SpringBootTest
class ProductTests {

	@Autowired
	ProductRepository repository;
	@Test
	void test() {
		//fail("Not yet implemented");
		
		System.out.println("good to go");
		Product p=new Product();
		p.setActualPrice(350);
		p.setAvail("yes");
		p.setCategory("comedy");
		p.setDesc("Dwanye  Johnson, Emily Blunt, Edger Ramirez ");
		p.setDiscount(0);
		p.setDurations("2hr:45min");
		p.setId(27287);
		p.setImagepath("./assets/images/jungle.jpeg");
		p.setName("Jungle Cruise");
		p.setPrice(350);
	
		assertNotNull(repository.save(p));
	}

}
